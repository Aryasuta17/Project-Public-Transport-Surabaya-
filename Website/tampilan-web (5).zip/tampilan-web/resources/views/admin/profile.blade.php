@extends('admin.layout')

@section('content')
    <h2>Admin Profile</h2>
    <p>Edit your profile settings.</p>
    <!-- Implement profile settings functionality -->
@endsection
