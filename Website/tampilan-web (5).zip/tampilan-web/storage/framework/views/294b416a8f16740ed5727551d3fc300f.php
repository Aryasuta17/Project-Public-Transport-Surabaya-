<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pencarian Rute</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Hasil Pencarian Rute</h1>
        
        <?php if(isset($routes) && count($routes) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Nama Rute</th>
                        <th>Nomor Bus</th>
                        <th>Driver</th>
                        <th>Jam Keberangkatan</th>
                        <th>Halte Awal</th>
                        <th>Halte Akhir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($route->route_name); ?></td>
                        <td><?php echo e($route->bus_number); ?></td>
                        <td><?php echo e($route->driver); ?></td>
                        <td><?php echo e($route->departure_time); ?></td>
                        <td><?php echo e($route->start_halte); ?></td>
                        <td><?php echo e($route->end_halte); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p><?php echo e($message ?? 'Rute tidak ditemukan.'); ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/bus/result.blade.php ENDPATH**/ ?>