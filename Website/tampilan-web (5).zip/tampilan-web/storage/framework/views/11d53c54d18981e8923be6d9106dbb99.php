<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Rute Bus</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #map {
            height: 500px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Detail Rute Bus</h1>
        <div class="row">
            <div class="col-md-6">
                <h2>Bus Nomor: <?php echo e($routeStops[0]->bus_number); ?></h2>
                <p>Driver: <?php echo e($routeStops[0]->driver); ?></p>
                <p>Rute: <?php echo e($routeStops[0]->route_name); ?></p>
            </div>
            <div class="col-md-6">
                <div id="map"></div>
            </div>
        </div>
    </div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([<?php echo e($routeStops[0]->latitude); ?>, <?php echo e($routeStops[0]->longitude); ?>], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        var routeStops = <?php echo json_encode($routeStops, 15, 512) ?>;
        var routeCoordinates = [];

        routeStops.forEach(function(stop) {
            routeCoordinates.push([stop.latitude, stop.longitude]);
            L.marker([stop.latitude, stop.longitude]).addTo(map)
                .bindPopup(stop.halte_name)
                .openPopup();
        });

        var routeLine = L.polyline(routeCoordinates, {color: 'blue'}).addTo(map);
    </script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/bus/details.blade.php ENDPATH**/ ?>