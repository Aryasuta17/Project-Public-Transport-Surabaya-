<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cari Rute Bus</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Cari Rute Bus</h1>

        <div class="row">
            <div class="col-md-6 mx-auto">
                <form action="/search-route" method="GET">
                    <div class="form-group">
                        <label for="startPoint">Pilih Titik Awal:</label>
                        <select class="form-control" name="startPoint" id="startPoint">
                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($position->id); ?>" <?php echo e(isset($startPoint) && $startPoint == $position->id ? 'selected' : ''); ?>>
                                    <?php echo e($position->halte_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="endPoint">Pilih Titik Akhir:</label>
                        <select class="form-control" name="endPoint" id="endPoint">
                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($position->id); ?>" <?php echo e(isset($endPoint) && $endPoint == $position->id ? 'selected' : ''); ?>>
                                    <?php echo e($position->halte_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Cari</button>
                </form>
            </div>
        </div>

        <?php if(isset($results) && count($results) > 0): ?>
            <div class="mt-5">
                <h2>Hasil Pencarian:</h2>
                <div class="row">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($result->route_name); ?></h5>
                                    <p class="card-text">Nama Driver: <?php echo e($result->driver); ?></p>
                                    <p class="card-text">Nama Bus: <?php echo e($result->bus_number); ?></p>
                                    <p class="card-text">Titik Awal: <?php echo e($result->start_halte); ?></p>
                                    <p class="card-text">Titik Akhir: <?php echo e($result->end_halte); ?></p>
                                    <p class="card-text">Jumlah Halte Dilewati: <?php echo e($result->stops_passed); ?></p>
                                    <p class="card-text">Jam Keberangkatan: <?php echo e($result->adjusted_departure_time); ?></p>
                                    <p class="card-text">Waktu Tempuh (menit): <?php echo e($result->travel_time); ?></p>
                                    <p class="card-text">Estimasi Waktu Tiba: <?php echo e($result->estimated_arrival_time); ?></p>
                                    <a href="#" class="btn btn-primary">Lanjut</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <p class="text-center mt-4">Tidak ada rute yang ditemukan.</p>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/bus/search.blade.php ENDPATH**/ ?>