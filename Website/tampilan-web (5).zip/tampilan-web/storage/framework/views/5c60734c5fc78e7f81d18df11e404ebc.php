

<?php $__env->startSection('content'); ?>
    <h2>Admin Profile</h2>
    <p>Edit your profile settings.</p>
    <!-- Implement profile settings functionality -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/admin/profile.blade.php ENDPATH**/ ?>