<?php

use Illuminate\Support\Facades\Route;

// Beranda
Route::get('/', function () {
    return view('home');
})->name('home');

// Login
Route::get('/login', function () {
    return view('login');
})->name('login');

// Register
Route::get('/register', function () {
    return view('register');
})->name('register');

// Pilihan Transportasi
Route::get('/pilihan-transportasi', function () {
    return view('pilihan_transportasi');
})->name('pilihan.transportasi');

// Berita
Route::get('/berita', function () {
    return view('berita');
})->name('berita');

// Kontak Kami
Route::get('/contact-us', function () {
    return view('contact_us');
})->name('contact.us');

// Diskusi
Route::get('/diskusi', function () {
    return view('diskusi');
})->name('diskusi');

// Pilihan Mode Transportasi
Route::get('/pilihan-mode-transportasi', function () {
    return view('pilihan_mode_transportasi');
})->name('pilihan.mode.transportasi');

// Pilihan Rute Transportasi
Route::get('/pilihan-rute-transportasi', function () {
    return view('pilihan_rute_transportasi');
})->name('pilihan.rute.transportasi');

// Rute Transportasi
Route::get('/rute-transportasi', function () {
    return view('rute_transportasi');
})->name('rute.transportasi');
