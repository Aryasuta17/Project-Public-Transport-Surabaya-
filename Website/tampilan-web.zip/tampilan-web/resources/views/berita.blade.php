<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Berita - Transportation Smart Destination</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
        }
        /* Navbar dan Footer sama seperti sebelumnya, dengan warna disesuaikan */
        nav {
            background-color: #2c3e50;
            /* ... */
        }
        nav ul li a {
            color: #ecf0f1;
            /* ... */
        }
        footer {
            background-color: #2c3e50;
            /* ... */
        }
        .container {
            padding: 50px 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 40px;
        }
        .berita-item {
            background-color: #fff;
            margin-bottom: 30px;
            padding: 20px;
            border-radius: 10px;
        }
        .berita-item h2 {
            margin-top: 0;
        }
        .berita-item img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .berita-item p {
            line-height: 1.6;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Berita Terbaru</h1>
        <!-- Contoh statis berita -->
        <div class="berita-item">
            <h2>Judul Berita 1</h2>
            <img src="{{ asset('images/berita1.jpg') }}" alt="Berita 1">
            <p>Konten berita 1...</p>
        </div>
        <div class="berita-item">
            <h2>Judul Berita 2</h2>
            <img src="{{ asset('images/berita2.jpg') }}" alt="Berita 2">
            <p>Konten berita 2...</p>
        </div>
        <!-- Tambahkan lebih banyak berita sesuai kebutuhan -->
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
