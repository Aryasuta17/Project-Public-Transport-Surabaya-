<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kontak Kami - Transportation Smart Destination</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('{{ asset('images/contact_background.jpg') }}') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }
        /* Navbar dan Footer sama seperti sebelumnya */
        nav {
            /* ... */
        }
        footer {
            /* ... */
        }
        .container {
            width: 500px;
            margin: 100px auto;
            background-color: rgba(0, 0, 0, 0.8);
            padding: 30px;
            border-radius: 10px;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input[type="text"], input[type="email"], textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: none;
            border-radius: 5px;
        }
        textarea {
            resize: vertical;
            height: 100px;
        }
        button {
            width: 100%;
            background-color: #e74c3c;
            color: #fff;
            padding: 15px;
            margin-top: 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        button:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Kontak Kami</h1>
        <form action="#" method="post">
            @csrf
            <label>Nama:</label>
            <input type="text" name="nama" required>
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Pesan:</label>
            <textarea name="pesan" required></textarea>
            <button type="submit">Kirim</button>
        </form>
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
