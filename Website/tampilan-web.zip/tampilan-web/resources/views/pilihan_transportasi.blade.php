<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pilihan Transportasi - Transportation Smart Destination</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('{{ asset('images/transportasi_background.jpg') }}') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }
        /* Navbar dan Footer sama seperti sebelumnya */
        nav {
            /* ... */
        }
        /* ... */
        .container {
            text-align: center;
            padding: 100px 20px;
        }
        h1 {
            font-size: 36px;
            margin-bottom: 40px;
        }
        .transport-options {
            display: flex;
            justify-content: center;
            gap: 50px;
        }
        .option {
            width: 200px;
            text-align: center;
        }
        .option img {
            width: 100%;
            border-radius: 10px;
        }
        .option a {
            display: block;
            margin-top: 15px;
            background-color: #e74c3c;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .option a:hover {
            background-color: #c0392b;
        }
        footer {
            /* ... */
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Pilih Jenis Transportasi</h1>
        <div class="transport-options">
            <div class="option">
                <img src="{{ asset('images/bus.jpg') }}" alt="Bus">
                <a href="{{ route('pilihan.mode.transportasi') }}?mode=bus">Bus</a>
            </div>
            <div class="option">
                <img src="{{ asset('images/kereta.jpg') }}" alt="Kereta">
                <a href="{{ route('pilihan.mode.transportasi') }}?mode=kereta">Kereta</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
