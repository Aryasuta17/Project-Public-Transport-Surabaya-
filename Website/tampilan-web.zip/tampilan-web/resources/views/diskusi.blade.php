<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Diskusi - Transportation Smart Destination</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
        }
        /* Navbar dan Footer sama seperti sebelumnya */
        nav {
            /* ... */
        }
        footer {
            /* ... */
        }
        .container {
            padding: 50px 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 40px;
        }
        .diskusi-item {
            background-color: #fff;
            margin-bottom: 30px;
            padding: 20px;
            border-radius: 10px;
        }
        .diskusi-item h2 {
            margin-top: 0;
        }
        .diskusi-item p {
            line-height: 1.6;
        }
        .button {
            display: block;
            width: 200px;
            margin: 0 auto;
            text-align: center;
            background-color: #e74c3c;
            color: #fff;
            padding: 15px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 30px;
        }
        .button:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Forum Diskusi</h1>
        <!-- Contoh statis diskusi -->
        <div class="diskusi-item">
            <h2>Topik Diskusi 1</h2>
            <p>Konten diskusi 1...</p>
        </div>
        <div class="diskusi-item">
            <h2>Topik Diskusi 2</h2>
            <p>Konten diskusi 2...</p>
        </div>
        <!-- Tambahkan lebih banyak diskusi sesuai kebutuhan -->
        <a href="#" class="button">Buat Diskusi Baru</a>
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
