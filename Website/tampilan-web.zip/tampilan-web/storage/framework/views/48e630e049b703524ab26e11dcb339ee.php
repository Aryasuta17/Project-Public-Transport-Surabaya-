<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pilihan Rute Transportasi - Transportation Smart Destination</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #ecf0f1;
            color: #2c3e50;
        }
        /* Navbar dan Footer sama seperti sebelumnya */
        nav {
            /* ... */
        }
        footer {
            /* ... */
        }
        .container {
            padding: 50px 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 40px;
        }
        .rute-list {
            list-style: none;
            padding: 0;
        }
        .rute-list li {
            background-color: #fff;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 10px;
        }
        .rute-list li a {
            text-decoration: none;
            color: #e74c3c;
            font-weight: bold;
        }
        .rute-list li a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Pilih Rute Transportasi</h1>
        <ul class="rute-list">
            <!-- Contoh statis rute -->
            <li><a href="<?php echo e(route('rute.transportasi')); ?>?id=1">Rute 1 - Terminal Purabaya ke Tunjungan Plaza</a></li>
            <li><a href="<?php echo e(route('rute.transportasi')); ?>?id=2">Rute 2 - Stasiun Gubeng ke Jembatan Suramadu</a></li>
            <!-- Tambahkan lebih banyak rute sesuai kebutuhan -->
        </ul>
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/pilihan_rute_transportasi.blade.php ENDPATH**/ ?>