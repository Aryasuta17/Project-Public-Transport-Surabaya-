<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Beranda - Transportation Smart Destination</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('<?php echo e(asset('images/home_background.jpg')); ?>') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }
        nav {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 15px;
        }
        nav ul {
            list-style: none;
            display: flex;
            justify-content: center;
            margin: 0;
        }
        nav ul li {
            margin: 0 15px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        .container {
            text-align: center;
            padding: 100px 20px;
        }
        h1 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        p {
            font-size: 24px;
            margin-bottom: 30px;
        }
        .button {
            background-color: #e74c3c;
            color: #fff;
            padding: 15px 30px;
            text-decoration: none;
            font-size: 18px;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #c0392b;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
            <li><a href="<?php echo e(route('berita')); ?>">Berita</a></li>
            <li><a href="<?php echo e(route('pilihan.transportasi')); ?>">Transportasi</a></li>
            <li><a href="<?php echo e(route('diskusi')); ?>">Diskusi</a></li>
            <li><a href="<?php echo e(route('contact.us')); ?>">Kontak Kami</a></li>
            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
        </ul>
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Selamat Datang di Transportation Smart Destination</h1>
        <p>Informasi terbaru seputar transportasi pintar di Surabaya.</p>
        <a href="<?php echo e(route('pilihan.transportasi')); ?>" class="button">Mulai Perjalanan</a>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2023 Transportation Smart Destination</p>
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/home.blade.php ENDPATH**/ ?>