<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rute Transportasi - Transportation Smart Destination</title>
    <!-- Sertakan CSS untuk peta jika menggunakan library -->
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }
        /* Navbar dan Footer sama seperti sebelumnya */
        nav {
            /* ... */
        }
        footer {
            /* ... */
        }
        .container {
            padding: 50px 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        #map {
            width: 100%;
            height: 500px;
            margin-bottom: 30px;
        }
        p {
            line-height: 1.6;
        }
    </style>
    <!-- Jika menggunakan Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Rute Transportasi</h1>
        <div id="map"></div>
        <p>Deskripsi rute transportasi...</p>
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Sertakan JS untuk peta jika menggunakan library -->
    <!-- Jika menggunakan Leaflet -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        // Inisialisasi peta
        var map = L.map('map').setView([-7.250445, 112.768845], 13); // Koordinat Surabaya
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        // Tambahkan marker atau garis rute jika diperlukan
        // Contoh marker:
        L.marker([-7.250445, 112.768845]).addTo(map)
            .bindPopup('Surabaya')
            .openPopup();
    </script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/rute_transportasi.blade.php ENDPATH**/ ?>