<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center mt-5">
    <h1>Welcome to Estetik Website</h1>
    <p class="lead">This is a simple, elegant, and aesthetic website built with Laravel.</p>
    <a class="btn btn-primary btn-lg" href="/about">Learn More</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/welcome.blade.php ENDPATH**/ ?>