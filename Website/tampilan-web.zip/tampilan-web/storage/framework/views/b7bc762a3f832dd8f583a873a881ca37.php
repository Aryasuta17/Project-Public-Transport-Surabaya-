<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'Website Transportasi'); ?></title>
    
    <!-- Link ke file CSS di public -->
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">

    <!-- Favicon -->
    <link rel="icon" href="https://example.com/favicon.png" type="image/png">
</head>
<body>
    <!-- Include Navbar -->
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <!-- Yield Content dari halaman-halaman lain -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Include Footer -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Link ke file JavaScript di public -->
    <script src="<?php echo e(url('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/layouts/app.blade.php ENDPATH**/ ?>