

<?php $__env->startSection('title', 'Rute di Surabaya'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4 text-center">Rute di Surabaya</h2>
<table class="table table-striped">
    <thead>
        <tr>
            <th>Jenis Transportasi</th>
            <th>Rute</th>
            <th>Jam Operasional</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Bus</td>
            <td>Terminal Purabaya - Tunjungan Plaza</td>
            <td>05:00 - 22:00</td>
        </tr>
        <tr>
            <td>Kereta</td>
            <td>Stasiun Gubeng - Stasiun Pasar Turi</td>
            <td>06:00 - 21:00</td>
        </tr>
        <tr>
            <td>Angkot</td>
            <td>Joyoboyo - Kenjeran</td>
            <td>05:30 - 20:00</td>
        </tr>
        <!-- Tambahkan rute lainnya sesuai kebutuhan -->
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/routes.blade.php ENDPATH**/ ?>