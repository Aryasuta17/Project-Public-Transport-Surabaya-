

<?php $__env->startSection('title', 'Pilih Transportasi'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4 text-center">Pilih Transportasi</h2>
<div class="row">
    <!-- Kartu Transportasi 1 -->
    <div class="col-md-4">
        <div class="card mb-4 shadow-sm">
            <img src="<?php echo e(asset('images/bus.jpg')); ?>" class="card-img-top" alt="Bus">
            <div class="card-body">
                <h5 class="card-title">Bus</h5>
                <p class="card-text">Layanan bus kota dengan rute yang luas.</p>
                <a href="#" class="btn btn-primary">Lihat Rute</a>
            </div>
        </div>
    </div>
    <!-- Kartu Transportasi 2 -->
    <div class="col-md-4">
        <div class="card mb-4 shadow-sm">
            <img src="<?php echo e(asset('images/train.jpg')); ?>" class="card-img-top" alt="Kereta">
            <div class="card-body">
                <h5 class="card-title">Kereta</h5>
                <p class="card-text">Kereta komuter untuk perjalanan antar kota.</p>
                <a href="#" class="btn btn-primary">Lihat Jadwal</a>
            </div>
        </div>
    </div>
    <!-- Kartu Transportasi 3 -->
    <div class="col-md-4">
        <div class="card mb-4 shadow-sm">
            <img src="<?php echo e(asset('images/taxi.jpg')); ?>" class="card-img-top" alt="Taksi">
            <div class="card-body">
                <h5 class="card-title">Taksi</h5>
                <p class="card-text">Layanan taksi 24 jam di seluruh kota.</p>
                <a href="#" class="btn btn-primary">Pesan Sekarang</a>
            </div>
        </div>
    </div>
    <!-- Tambahkan kartu lainnya sesuai kebutuhan -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/choose-transportation.blade.php ENDPATH**/ ?>