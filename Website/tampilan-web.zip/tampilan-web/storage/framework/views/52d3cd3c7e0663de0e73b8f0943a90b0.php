<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Transportation Smart Destination</title>
    <style>
        /* Gaya sama seperti login page */
        body {
            /* ... */
            background: url('<?php echo e(asset('images/register_background.jpg')); ?>') no-repeat center center fixed;
            /* ... */
        }
        /* Gaya lainnya sama seperti login page */
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav>
        <!-- ... -->
    </nav>

    <!-- Konten -->
    <div class="container">
        <h1>Daftar Akun Baru</h1>
        <form action="#" method="post">
            <?php echo csrf_field(); ?>
            <label>Nama:</label>
            <input type="text" name="name" required>
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Password:</label>
            <input type="password" name="password" required>
            <button type="submit">Daftar</button>
        </form>
        <p>Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Login di sini</a>.</p>
    </div>

    <!-- Footer -->
    <footer>
        <!-- ... -->
    </footer>

    <!-- Script -->
    <script>
        // Tambahkan script interaktif di sini jika diperlukan
    </script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/register.blade.php ENDPATH**/ ?>