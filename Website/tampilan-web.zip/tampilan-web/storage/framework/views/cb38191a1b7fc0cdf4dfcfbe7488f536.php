

<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <h1>Selamat Datang di Website Kami</h1>
    <p>Pilih layanan transportasi yang sesuai untuk Anda!</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/pages/home.blade.php ENDPATH**/ ?>