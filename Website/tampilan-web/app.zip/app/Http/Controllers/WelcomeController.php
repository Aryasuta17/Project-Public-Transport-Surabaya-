<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News; // Pastikan model News sudah ada

class WelcomeController extends Controller
{
    public function index()
    {
        // Mengambil semua berita dari database
        $news = News::all();

        // Mengirimkan data berita ke view welcome.blade.php
        return view('welcome', compact('news'));
    }
}
