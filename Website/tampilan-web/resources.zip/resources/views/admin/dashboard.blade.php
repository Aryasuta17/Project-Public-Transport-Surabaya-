<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Transportation Smart Destination</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #333;
            padding: 20px;
            color: white;
            text-align: center;
        }

        h1 {
            margin: 0;
        }

        .container {
            margin: 20px auto;
            max-width: 1200px;
            padding: 20px;
        }

        .menu {
            display: flex;
            justify-content: space-around;
            background-color: #444;
            padding: 15px;
            border-radius: 8px;
        }

        .menu a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            background-color: #ff6347;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .menu a:hover {
            background-color: #ff4500;
        }

        .content {
            margin-top: 20px;
        }

        .content h2 {
            font-size: 28px;
            color: #333;
        }

        .content p {
            font-size: 16px;
            color: #666;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        .btn {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-warning {
            background-color: #ffc107;
        }

        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
    </header>

    <div class="container">
        <!-- Menu Navigasi Admin -->
        <div class="menu">
            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
            <a href="{{ route('admin.news') }}">Manage Berita</a>
            <a href="{{ route('logout') }}">Logout</a>
        </div>

        <!-- Konten Dashboard -->
        <div class="content">
            <h2>Selamat datang, Admin!</h2>
            <p>Ini adalah halaman admin di mana Anda bisa mengelola berita yang ditampilkan di homepage.</p>
        </div>
    </div>
</body>
</html>
