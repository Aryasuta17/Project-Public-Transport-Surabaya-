document.addEventListener('DOMContentLoaded', function() {
    console.log("Website is fully loaded and ready!");
});
