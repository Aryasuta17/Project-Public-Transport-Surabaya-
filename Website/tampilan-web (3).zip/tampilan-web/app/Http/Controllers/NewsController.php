<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News; // Model untuk berita

class NewsController extends Controller
{
    public function index()
    {
        // Mengambil semua berita dari database
        $news = News::all();

        // Menampilkan berita di homepage
        return view('welcome', compact('news'));
    }
}
