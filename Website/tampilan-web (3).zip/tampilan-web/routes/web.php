<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Admin\NewsController;

// Route halaman utama (welcome)
Route::get('/', function () {
    return view('welcome');
})->name('welcome');

// Route login
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);

// Route register
Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register']);

// Route logout
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Admin routes (dengan CRUD untuk berita)
Route::middleware('auth')->group(function () {
    Route::get('/admin', [NewsController::class, 'index'])->name('admin');
    Route::resource('news', NewsController::class);
});

