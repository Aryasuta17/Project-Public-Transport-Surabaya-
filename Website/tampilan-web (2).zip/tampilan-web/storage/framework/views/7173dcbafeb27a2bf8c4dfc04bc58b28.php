

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Pilih Transportasi</h2>
    <ul>
        <li><a href="#">Bus</a></li>
        <li><a href="#">Kereta Api</a></li>
        <li><a href="#">Pesawat</a></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/pages/choose-transportation.blade.php ENDPATH**/ ?>