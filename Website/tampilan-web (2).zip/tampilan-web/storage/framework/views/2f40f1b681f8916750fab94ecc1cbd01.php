<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">Admin Panel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.manage.users')); ?>">Manage Users</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.manage.routes')); ?>">Manage Routes</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.manage.transport')); ?>">Manage Transport</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.settings')); ?>">Settings</a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-danger text-white" href="#">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/admin/layouts/navbar.blade.php ENDPATH**/ ?>