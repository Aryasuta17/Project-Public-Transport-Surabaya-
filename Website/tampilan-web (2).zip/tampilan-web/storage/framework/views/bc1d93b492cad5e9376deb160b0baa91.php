<div class="footer">
    <p>&copy; 2024 Website Transportasi. All rights reserved.</p>
</div>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/partials/footer.blade.php ENDPATH**/ ?>