<nav class="navbar">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <a href="<?php echo e(url('/choose-transportation')); ?>">Pilih Transportasi</a>
    <a href="<?php echo e(url('/routes')); ?>">Rute</a>
    <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('login')); ?>">Login</a>
        <a href="<?php echo e(route('register')); ?>">Register</a>
    <?php else: ?>
        <a href="<?php echo e(route('logout')); ?>">Logout</a>
    <?php endif; ?>
</nav>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/partials/navbar.blade.php ENDPATH**/ ?>