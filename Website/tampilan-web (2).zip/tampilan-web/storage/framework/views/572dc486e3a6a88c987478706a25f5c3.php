<footer class="footer mt-auto py-3 bg-light">
  <div class="container">
    <span class="text-muted">&copy; 2023 Transportation Smart Destination - Admin Panel</span>
  </div>
</footer>
<?php /**PATH C:\Users\ASUS\OneDrive\Desktop\SMT 5\Basdat\Project Keren\Website\tampilan-web\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>